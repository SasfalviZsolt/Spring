package com.example.demo.auto.Service;

import com.example.demo.auto.entity.AutoEntity;
import com.example.demo.core.CoreCRUDService;

public interface AutoService extends CoreCRUDService<AutoEntity>
{

}
