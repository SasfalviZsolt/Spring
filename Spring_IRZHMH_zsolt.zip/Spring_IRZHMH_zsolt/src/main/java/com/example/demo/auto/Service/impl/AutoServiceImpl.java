package com.example.demo.auto.Service.impl;

import com.example.demo.auto.entity.AutoEntity;
import com.example.demo.auto.Service.AutoService;
import com.example.demo.core.impl.CoreCRUDServiceImpl;

import org.springframework.stereotype.Service;




@Service
public class AutoServiceImpl extends CoreCRUDServiceImpl<AutoEntity> implements AutoService {
@Override
    protected void updateCore(AutoEntity updatableEntity, AutoEntity entity){
        updatableEntity.setGyarto(entity.getGyarto());
        updatableEntity.setAjtokszama(entity.getAjtokszama());
        updatableEntity.setGyartasiev(entity.getGyartasiev());
        updatableEntity.setTipus(entity.getTipus());
    }
    @Override
    protected Class<AutoEntity> getManagedClass(){
    return AutoEntity.class;
    }
}
