package com.example.demo.auto.controller;


import com.example.demo.auto.Service.AutoService;
import com.example.demo.auto.controller.resp.AutoListResponse;
import com.example.demo.auto.entity.AutoEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class AutoController {

    @Autowired
    private AutoService service;
    @GetMapping(value = "/api/auto/{id}")
    public ResponseEntity findById(@PathVariable Long id) {
        AutoEntity entity = service.findById(id);
        if (entity != null) {
            return ResponseEntity.ok(entity);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    @GetMapping(value = "/api/auto")
    public ResponseEntity<AutoListResponse> findAll() {
        AutoListResponse response = new AutoListResponse();
        response.setAut(service.findAll());
        return ResponseEntity.ok(response);
    }


    //create - egy könyv létrehozása
    @PostMapping(value = "/api/auto", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<AutoEntity> create(@RequestBody AutoEntity entity) {
        service.create(entity);
        return ResponseEntity.ok(entity);
    }

    //update - módosítást
    @PutMapping(value = "/api/auto", consumes = MediaType.APPLICATION_JSON_VALUE)
    public AutoEntity update(@RequestBody AutoEntity entity)
    {
        return service.update(entity);
    }


    @DeleteMapping(value = "/api/auto/{id}")
    public ResponseEntity<String> deleteById(@PathVariable Long id) {
        if(service.deleteById(id)){
            return ResponseEntity.ok("Sikeres művelet");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

}
