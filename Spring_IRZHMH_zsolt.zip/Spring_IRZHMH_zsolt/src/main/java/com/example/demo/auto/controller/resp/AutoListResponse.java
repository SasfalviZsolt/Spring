package com.example.demo.auto.controller.resp;

import com.example.demo.auto.entity.AutoEntity;

import java.util.List;

public class AutoListResponse {
    private List<AutoEntity> aut;

    public List<AutoEntity> getAut() {
        return aut;
    }

    public void setAut(List<AutoEntity> aut) {
        this.aut = aut;
    }
}
