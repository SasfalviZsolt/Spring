package com.example.demo.auto.entity;

import com.example.demo.core.entity.CoreEntity;
import com.example.demo.gyarto.GyartoEntity;

import javax.persistence.*;

@Entity
@Table(name = "auto")
public class AutoEntity extends CoreEntity {

    @Column(name = "tipus")
    private String tipus;
    @Column(name = "ajtokszama")
    private String ajtokszama;
    @Column(name = "gyartasiev")
    private String gyartasiev;

    @ManyToOne
    @JoinColumn(name = "gyarto_id")
    private GyartoEntity gyarto;


    public AutoEntity() {
    }

    public String getAjtokszama() {
        return ajtokszama;
    }

    public void setAjtokszama(String ajtokszama) {
        this.ajtokszama = ajtokszama;
    }

    public String getGyartasiev() {
        return gyartasiev;
    }

    public void setGyartasiev(String gyartasiev) {
        this.gyartasiev = gyartasiev;
    }

    public String getTipus()
    {
        return tipus;
    }

    public void setTipus(String tipus)
    {
        this.tipus = tipus;
    }


   public GyartoEntity getGyarto() {
       return gyarto;
   }

    public void setGyarto(GyartoEntity gyarto) {
        this.gyarto = gyarto;
    }


}
