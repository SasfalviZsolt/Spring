package com.example.demo.core.component;

import com.example.demo.security.config.SecurityUtils;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;

public class MenuComponent extends HorizontalLayout {
    public MenuComponent(){
        Anchor autoLink=new Anchor();
        autoLink.setHref("/automanager");
        autoLink.setText("Autok");

        Anchor gyartoLink=new Anchor();
        gyartoLink.setHref("/gyartomanager");
        gyartoLink.setText("gyarto");
        add(autoLink, gyartoLink);

        if (SecurityUtils.isAdmin()) {
            Anchor userLink = new Anchor();
            userLink.setHref("/usermanager");
            userLink.setText("users");
            add(userLink);
        }
    }
}
