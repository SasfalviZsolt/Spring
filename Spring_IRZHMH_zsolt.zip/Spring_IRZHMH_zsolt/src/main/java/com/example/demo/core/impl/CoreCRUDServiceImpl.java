package com.example.demo.core.impl;

import com.example.demo.core.CoreCRUDService;
import com.example.demo.core.entity.CoreEntity;
import org.springframework.beans.factory.annotation.Autowired;


import javax.persistence.EntityManager;
import java.util.List;

public abstract class CoreCRUDServiceImpl<T extends CoreEntity> implements CoreCRUDService<T> {

    @Autowired
    protected EntityManager entityManager;


    public CoreCRUDServiceImpl() {

    }
    @Override
    public List<T> findAll()
    {
        return entityManager.createQuery("SELECT a FROM "+getManagedClass().getSimpleName()+" a", getManagedClass()).getResultList();

    }
    @Override
    public T create(T entity)
    {
        entityManager.persist(entity);
        return entity;
    }
    @Override
    public boolean deleteById(Long id) {
        T gyartoEntity = findById(id);
        if(gyartoEntity==null)
            entityManager.remove(gyartoEntity);
        return true;

    }
    @Override
    public T update(T entity) {
        T updatebleAuto = findById(entity.getId());
        if (updatebleAuto != null) {
            updateCore(updatebleAuto,entity);
            entityManager.merge(updatebleAuto);

        }
        return updatebleAuto;

    }
    @Override
    public T findById(Long id) {

        return entityManager.find(getManagedClass(), id);
    }
    protected abstract void updateCore(T updatableEntity,T entity);
    protected abstract Class<T> getManagedClass();
}
