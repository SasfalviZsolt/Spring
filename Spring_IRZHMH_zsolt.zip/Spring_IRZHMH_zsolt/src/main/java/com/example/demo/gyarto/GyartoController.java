package com.example.demo.gyarto;


import com.example.demo.gyarto.service.impl.GyartoServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class GyartoController {

    @Autowired
    private GyartoServiceImpl service;

    @GetMapping(value = "/api/gyarto/{id}")
    public ResponseEntity findById(@PathVariable Long id) {
        GyartoEntity entity = service.findById(id);
        if (entity != null) {
            return ResponseEntity.ok(entity);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    @GetMapping(value = "/api/gyarto")
    public ResponseEntity<GyartoListResponse> findAll() {
        GyartoListResponse response = new GyartoListResponse();
        response.setGyartok(service.findAll());
        return ResponseEntity.ok(response);
    }


    //create - egy könyv létrehozása
    @PostMapping(value = "/api/gyarto", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GyartoEntity> create(@RequestBody GyartoEntity entity) {
        service.create(entity);
        return ResponseEntity.ok(entity);
    }

    //update - módosítást
    @PutMapping(value = "/api/gyarto", consumes = MediaType.APPLICATION_JSON_VALUE)
    public GyartoEntity update(@RequestBody GyartoEntity entity) {
        return service.update(entity);
    }


    @DeleteMapping(value = "/api/gyarto/{id}")
    public ResponseEntity<String> deleteById(@PathVariable Long id) {
        if(service.deleteById(id)){
            return ResponseEntity.ok("Sikeres művelet");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

}
