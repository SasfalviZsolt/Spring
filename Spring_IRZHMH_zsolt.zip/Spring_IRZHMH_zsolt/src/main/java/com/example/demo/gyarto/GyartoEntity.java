package com.example.demo.gyarto;

import com.example.demo.core.entity.CoreEntity;

import javax.persistence.*;

@Entity
@Table(name = "gyarto")
public class GyartoEntity extends CoreEntity {

    @Column(name = "nev")
    private String nev;


    public GyartoEntity() {
    }


    public String getNev() {
        return nev;
    }

    public void setNev(String nev) {
        this.nev = nev;
    }


}
