package com.example.demo.gyarto;

import java.util.List;

public class GyartoListResponse {

    private List<GyartoEntity> gyartok;

    public GyartoListResponse() {
    }

    public GyartoListResponse(List<GyartoEntity> gyartok) {
        this.gyartok = gyartok;
    }

    public List<GyartoEntity> getGyartok() {
        return gyartok;
    }

    public void setGyartok(List<GyartoEntity> gyartok) {
        this.gyartok = gyartok;
    }
}
