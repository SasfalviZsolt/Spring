package com.example.demo.gyarto.service;

import com.example.demo.core.CoreCRUDService;
import com.example.demo.gyarto.GyartoEntity;



public interface GyartoService extends CoreCRUDService<GyartoEntity> {

}
