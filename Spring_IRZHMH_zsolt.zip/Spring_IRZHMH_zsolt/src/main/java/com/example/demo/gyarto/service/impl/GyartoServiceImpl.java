package com.example.demo.gyarto.service.impl;

import com.example.demo.gyarto.service.GyartoService;
import com.example.demo.core.impl.CoreCRUDServiceImpl;
import com.example.demo.gyarto.GyartoEntity;
import org.springframework.stereotype.Service;

@Service

public class GyartoServiceImpl  extends CoreCRUDServiceImpl<GyartoEntity> implements GyartoService {

    @Override
    protected void updateCore(GyartoEntity updatableEntity, GyartoEntity entity){
        updatableEntity.setNev(entity.getNev());
    }
    @Override
    protected Class<GyartoEntity> getManagedClass(){
        return GyartoEntity.class;
    }

}
