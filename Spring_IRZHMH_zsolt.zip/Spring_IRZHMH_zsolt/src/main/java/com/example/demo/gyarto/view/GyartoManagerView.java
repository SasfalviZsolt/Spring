package com.example.demo.gyarto.view;

import com.example.demo.core.component.MenuComponent;
import com.example.demo.gyarto.GyartoEntity;
import com.example.demo.gyarto.service.GyartoService;
import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.router.Route;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.PostConstruct;

@Route
public class GyartoManagerView extends VerticalLayout {

    private GyartoEntity selectedGyarto;
    private VerticalLayout form;
    private TextField Nev;
    private Binder<GyartoEntity> binder;

    @Autowired
    private GyartoService service;

    @PostConstruct
    public void init() {
        add(new MenuComponent());
        Grid<GyartoEntity> grid = new Grid<>();
        grid.setItems(service.findAll());
        grid.addColumn(GyartoEntity::getId).setHeader("ID");
        grid.addColumn(GyartoEntity::getNev).setHeader("Nev");
        addButtonBar(grid);
        add(grid);
        addForm(grid);
    }
    private void addForm(Grid<GyartoEntity> grid) {
        form = new VerticalLayout();
        binder = new Binder<>(GyartoEntity.class);
        Nev = new TextField();
        form.add(new Text("Nev"), Nev);

        Button saveBtn = new Button();
        saveBtn.setText("Save");
        saveBtn.addClickListener(buttonClickEvent -> {
            if (selectedGyarto.getId() != null) {
                service.update(selectedGyarto);
            } else {
                service.create(selectedGyarto);
            }
            grid.setItems(service.findAll());
            form.setVisible(false);
        });
        form.add(saveBtn);
        add(form);
        form.setVisible(false);
        binder.bindInstanceFields(this);
    }


    private void addButtonBar(Grid<GyartoEntity> grid) {
        HorizontalLayout buttonBar = new HorizontalLayout();

        Button deleteBtn = new Button();
        deleteBtn.setEnabled(false);
        deleteBtn.setText("Delete");
        deleteBtn.setIcon(VaadinIcon.TRASH.create());
        deleteBtn.addClickListener(buttonClickEvent -> {
            service.deleteById(selectedGyarto.getId());
            grid.setItems(service.findAll());
            selectedGyarto = null;
            deleteBtn.setEnabled(false);
            form.setVisible(false);
            Notification.show("Successfully deleted");
        });
        grid.asSingleSelect().addValueChangeListener(event -> {
            selectedGyarto = event.getValue();
            deleteBtn.setEnabled(selectedGyarto != null);
            form.setVisible(selectedGyarto != null);
            binder.setBean(selectedGyarto);
        });

        Button addBtn = new Button();
        addBtn.setText("Add");
        addBtn.addClickListener(buttonClickEvent -> {
            selectedGyarto = new GyartoEntity();
            binder.setBean(selectedGyarto);
            form.setVisible(true);
        });
        addBtn.setIcon(VaadinIcon.PLUS.create());
        buttonBar.add(deleteBtn, addBtn);
        add(buttonBar);
    }
}
