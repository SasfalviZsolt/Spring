package com.example.demo.user.service;

import com.example.demo.core.CoreCRUDService;
import com.example.demo.user.Entity.AppRoleEntity;

public interface AppRoleService extends CoreCRUDService<AppRoleEntity> {
}
