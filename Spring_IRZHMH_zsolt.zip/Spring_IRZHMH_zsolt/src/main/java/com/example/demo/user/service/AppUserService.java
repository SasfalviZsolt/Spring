package com.example.demo.user.service;

import com.example.demo.core.CoreCRUDService;
import com.example.demo.user.Entity.AppUserEntity;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface AppUserService extends CoreCRUDService<AppUserEntity>, UserDetailsService {
}
